<?php
class ModelExtensionPaymentCloudbanking extends Model {
	public function install() {
		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cloudbanking_card` (
			  `order_id` INT ,
			  `banktransation_id` INT ,
			  `cardtoken` VARCHAR(500) ,
			  PRIMARY KEY (`order_id`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");

	}

	public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cloudbanking_card`");
		$this->log('Module uninstalled');
	}

	public function getOrderInfo($order_id) {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "cloudbanking_card` WHERE `order_id` = '" . $order_id . "' LIMIT 1");
        return $order;
		} 
		
   
	public function addTransaction($response,$order_info) {
        $banktransaction_id=$response->getTransactionReference();
        $cardtoken=$response->getCardReference();
        $order_id=$order_info['order_id'];
		$this->db->query("INSERT INTO `" . DB_PREFIX . "cloudbanking_card` SET `order_id` = '" . $order_id . "', `banktransation_id` = '" . $banktransaction_id . "', `cardtoken` = '" . $cardtoken . "'");
        
    }

}