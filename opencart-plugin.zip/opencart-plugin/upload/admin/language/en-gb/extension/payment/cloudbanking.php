<?php
// Heading
$_['heading_title']                = 'Cloudbanking';

// Text
$_['text_extension']               = 'Extensions';
$_['text_success']                 = 'Success: You have modified Cloudbanking account details!';
$_['text_edit']                    = 'Edit Cloudbanking';
$_['text_test']                    = 'Test';
$_['text_live']                    = 'Live';
$_['text_authorization']           = 'Cloudbanking';
$_['text_capture']                 = 'Capture';
$_['text_refunds_success']         = 'Refund request was successful';

// Entry
$_['entry_authkey']                 = 'Autkey';
$_['entry_api_version']             = 'ApiVersion';
$_['entry_customer_id']             = 'Customer ID';
$_['entry_method']                  = 'Transaction Method';
$_['entry_order_status']            = 'Order Status';
$_['entry_status']                  = 'Status';

// Error
$_['error_permission']              = 'Warning: You do not have permission to modify payment Cloudbanking!';
$_['error_authkey']                 = 'Authkey Required';
$_['error_api_version']             = 'Api Version Required!';
$_['error_customer_id']             = 'Customer ID Required!';
$_['error_no_order']                = 'error Refund';

$_['text_payment_info']             = 'Payment Information';
$_['text_payment_method']           = 'Payment Method';
$_['text_card']                     = 'Card';
$_['text_echeck']                   = 'eCheck';
$_['text_order_total']              = 'Order Total';
$_['text_refund_payment']           = 'Refund Payment';
$_['text_reference']                = 'Reference';
$_['text_update']                   = 'Update';
$_['text_order_total']              = 'Order Total';
$_['text_total_captured']           = 'Total Captured';
$_['text_capture_payment']          = 'Capture Payment';
$_['text_refund_payment']           = 'Refund Payment';
$_['text_void']                     = 'Void';
$_['text_transactions']             = 'Transactions';
$_['text_column_type']              = 'Type';
$_['text_column_reference']         = 'Reference';
$_['text_column_amount']            = 'Amount';
$_['text_column_status']            = 'Status';
$_['text_column_date_modified']     = 'Date Modified';
$_['text_column_date_added']        = 'Date Added';
$_['text_column_update']            = 'Update';
$_['text_column_void']              = 'Void';
$_['text_confirm_capture']          = 'Are you sure you want to capture the payment?';
$_['text_refunds']                  = 'Are you sure you want to refund the payment?';
$_['text_inquire_success']          = 'Inquire was successful';
$_['text_capture_success']          = 'Capture request was successful';
$_['text_refund_success']           = 'Refund request was successful';
$_['text_void_success']             = 'Void request was successful';

// Button
$_['button_inquire_all']            = 'Inquire All';
$_['button_capture']                = 'Capture';
$_['button_refund']                 = 'Refund';
$_['button_void_all']               = 'Void All';
$_['button_inquire']                = 'Inquire';
$_['button_void']                   = 'Void';